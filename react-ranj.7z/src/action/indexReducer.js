import cardReducer from "./cardReducer";
import { combineReducers } from "redux";

export default combineReducers({
  cardReducer,
});
