import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import Cards from "../comps/Cards";
import { basic } from "./cardAction";
const mapDispatchToProps = (dispatch) => {
  return {
    basic: () => {
      dispatch(basic());
    },
  };
};

const mapStateToProps = (state) => {
  return { abc: state.cardReducer.abc };
};

const cardContainer = connect(mapStateToProps, mapDispatchToProps)(Cards);
export default cardContainer;
