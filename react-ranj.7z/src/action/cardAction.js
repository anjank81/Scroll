export const BASIC_REQUEST = "BASIC_REQUEST";
export const BASIC_SUCCESS = "BASIC_SUCCESS";
export const BASIC_FAILURE = "BASIC_FAILURE";

export function basicRequest() {
  return { type: BASIC_REQUEST, status: "Requesting" };
}

export function basicSuccess(abc) {
  return { type: BASIC_SUCCESS, status: "Success", abc };
}

export function basicFailure() {
  return { type: BASIC_FAILURE, status: "Failure" };
}
export function basic() {
  return async (dispatch) => {
    console.log("asmsma");
    dispatch(basicSuccess("abc"));
  };
}
