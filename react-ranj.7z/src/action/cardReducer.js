import * as cardAction from "./cardAction";

const cardReducer = (
  state = {
    abc: null,
  },
  action
) => {
  switch (action.type) {
    case cardAction.BASIC_SUCCESS:
      return Object.assign({}, state, {
        abc: action.abc,
      });
    default:
      return state;
  }
};
export default cardReducer;
