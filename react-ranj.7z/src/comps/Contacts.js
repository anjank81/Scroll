import React, { Component } from "react";
import { Card } from "primereact/card";
import "primeicons/primeicons.css";
import "primereact/resources/themes/nova-light/theme.css";
import "primereact/resources/primereact.css";

import "../css/card-layout.scss";

export default class Contacts extends Component {
  constructor() {
    super();
    this.state = {};
  }
  render() {
    const header = (
      <img
        alt="Card"
        src="showcase/demo/images/usercard.png"
        srcSet="https://www.primefaces.org/wp-content/uploads/2020/05/placeholder.png"
      />
    );

    return (
      <div className="row">
        <div className="column">
          <Card
            title="Tony Stark"
            subTitle="Subtitle"
            className="cardlarge"
            header={header}
          >
            <div>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit.
              Inventore sed consequuntur error repudiandae numquam deserunt
              quisquam repellat libero asperiores earum nam nobis, culpa ratione
              quam perferendis esse, cupiditate neque quas!
            </div>
          </Card>
        </div>
        <div className="column">
          <Card
            title="Tony Stark"
            subTitle="Subtitle"
            className="cardlarge"
            header={header}
          >
            <div>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit.
              Inventore sed consequuntur error repudiandae numquam deserunt
              quisquam repellat libero asperiores earum nam nobis, culpa ratione
              quam perferendis esse, cupiditate neque quas!
            </div>
          </Card>
        </div>
        <div className="column">
          <Card
            title="Tony Stark"
            subTitle="Subtitle"
            className="cardlarge"
            header={header}
          >
            <div>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit.
              Inventore sed consequuntur error repudiandae numquam deserunt
              quisquam repellat libero asperiores earum nam nobis, culpa ratione
              quam perferendis esse, cupiditate neque quas!
            </div>
          </Card>
        </div>
        <div className="column">
          <Card
            title="Tony Stark"
            subTitle="Subtitle"
            className="cardlarge"
            header={header}
          >
            <div>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit.
              Inventore sed consequuntur error repudiandae numquam deserunt
              quisquam repellat libero asperiores earum nam nobis, culpa ratione
              quam perferendis esse, cupiditate neque quas!
            </div>
          </Card>
        </div>
      </div>
    );
  }
}
