import React, { Component } from "react";
import { Card } from "primereact/card";
import "primeicons/primeicons.css";
import "primereact/resources/themes/nova-light/theme.css";
import "primereact/resources/primereact.css";

import "../css/card-layout.scss";
import Contacts from "./Contacts";
import ActionBar from "./ActionBar";

export default class Cards extends Component {
  constructor() {
    super();
    this.state = {};
  }
  render() {
    return (
      <div>
        <ActionBar {...this.props} />
        <div className="row">
          <div className="column">
            <Card className="card" title="Sushant's Case Continues">
              <div>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Inventore sed consequuntur error repudiandae numquam deserunt
                quisquam repellat libero asperiores earum nam nobis, culpa
                ratione quam perferendis esse, cupiditate neque quas!
              </div>
            </Card>
          </div>
          <div className="column">
            <Card className="card" title="Simple Card">
              <div>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Inventore sed consequuntur error repudiandae numquam deserunt
                quisquam repellat libero asperiores earum nam nobis, culpa
                ratione quam perferendis esse, cupiditate neque quas!
              </div>
            </Card>
          </div>
          <div className="column">
            <Card className="card" title="Rafaels first batch in India">
              <div>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Inventore sed consequuntur error repudiandae numquam deserunt
                quisquam repellat libero asperiores earum nam nobis, culpa
                ratione quam perferendis esse, cupiditate neque quas!
              </div>
            </Card>
          </div>
          <div className="column">
            <Card className="card" title="Simple Card">
              <div>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Inventore sed consequuntur error repudiandae numquam deserunt
                quisquam repellat libero asperiores earum nam nobis, culpa
                ratione quam perferendis esse, cupiditate neque quas!
              </div>
            </Card>
          </div>
          <Contacts />
        </div>
      </div>
    );
  }
}
