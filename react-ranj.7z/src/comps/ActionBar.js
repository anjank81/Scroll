import React, { Component } from "react";
import { Sidebar } from "primereact/sidebar";
import { Button } from "primereact/button";
import "primeicons/primeicons.css";
import "primereact/resources/themes/nova-light/theme.css";
import "primereact/resources/primereact.css";
import "../css/action-bar.scss";

export default class ActionBar extends Component {
  constructor() {
    super();
    this.state = {
      visibleLeft: false,
    };
  }
  render() {
    console.log(this.props);
    return (
      <div>
        <Sidebar
          className="action-bar"
          visible={this.state.visibleLeft}
          modal={false}
        >
          <h1>Contents</h1>
          <div>
            <h2 onClick={this.props.basic}>Contacts</h2>
            <h2>Insights</h2>
          </div>
        </Sidebar>
        <Button
          className={
            this.state.visibleLeft
              ? "action-bar-toggle_open"
              : "action-bar-toggle_close"
          }
          icon={
            this.state.visibleLeft ? "pi pi-caret-left" : "pi pi-caret-right"
          }
          onClick={() =>
            this.setState({ visibleLeft: !this.state.visibleLeft })
          }
        />
      </div>
    );
  }
}
